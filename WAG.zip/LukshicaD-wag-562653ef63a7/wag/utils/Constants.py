KNOWLEDGE_BASE_URL = "wag/data/knowledgeBase/web_accessibility_spec.xml"
PHANTOMJS_EXE = "wag/utils/phantomjs.exe"
TEST_DB_NAME = 'wag_test'
DEMO_DB_NAME = 'wag'