import os.path

PROJECT_ROOT = os.path.abspath(os.path.dirname(__file__))