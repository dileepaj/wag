from wag import app
import setup
app.run(host='0.0.0.0', debug=True)