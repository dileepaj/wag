from bs4 import BeautifulSoup
#Refer BeautifulSoup 

class Rules:
    def __init__(self):        
        self.ruleCollection = {
         "1" : self.rule1,         
        }
 
    def getRule(self, id):
        return self.ruleCollection[id]
  
    def rule1(self,dom):
        #Enter Your code here
    


