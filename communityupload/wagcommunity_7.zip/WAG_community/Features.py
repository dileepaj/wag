class Feature:
    def __init__(self, title, disability,rank,priority,level,error,description,solution,rule):
        self.title = title
        self.disability = disability
        self.rank = rank
        self.priority = priority
        self.level = level
        self.error = error
        self.description = description
        self.solution = solution
        self.rule = rule 